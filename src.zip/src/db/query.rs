use anyhow::Result;
use sqlx::{Column, PgPool, Row};

use super::models::QueryResult;

pub async fn execute_query(pool: &PgPool, sql: &str) -> Result<QueryResult> {
    let rows = sqlx::query(sql).fetch_all(pool).await?;

    if rows.is_empty() {
        return Ok(QueryResult {
            columns: vec![],
            rows: vec![],
            rows_affected: 0,
        });
    }

    let columns: Vec<String> = rows[0]
        .columns()
        .iter()
        .map(|c| c.name().to_string())
        .collect();

    let data = rows
        .iter()
        .map(|row| {
            columns
                .iter()
                .enumerate()
                .map(|(i, _)| {
                    row.try_get::<String, _>(i)
                        .or_else(|_| row.try_get::<i32, _>(i).map(|v| v.to_string()))
                        .or_else(|_| row.try_get::<i64, _>(i).map(|v| v.to_string()))
                        .or_else(|_| row.try_get::<f64, _>(i).map(|v| v.to_string()))
                        .or_else(|_| row.try_get::<bool, _>(i).map(|v| v.to_string()))
                        .or_else(|_| row.try_get::<uuid::Uuid, _>(i).map(|v| v.to_string()))
                        .or_else(|_| {
                            row.try_get::<chrono::NaiveDateTime, _>(i)
                                .map(|v| v.to_string())
                        })
                        .or_else(|_| {
                            row.try_get::<chrono::NaiveDate, _>(i)
                                .map(|v| v.to_string())
                        })
                        .or_else(|_| {
                            row.try_get::<Option<String>, _>(i)
                                .map(|_| "NULL".to_string())
                        })
                        .unwrap_or_else(|_| "NULL".to_string())
                })
                .collect()
        })
        .collect();

    Ok(QueryResult {
        columns,
        rows: data,
        rows_affected: rows.len() as u64,
    })
}
