use crate::app::state::AppState;
use crate::ui::theme::Theme;

pub fn show_titlebar(ui: &mut egui::Ui, state: &mut AppState, theme: &Theme) {
    ui.horizontal(|ui| {
        ui.label(
            egui::RichText::new("pgTool")
                .color(theme.text)
                .strong()
                .size(14.0),
        );

        ui.separator();
        if state.is_loading() {
            ui.spinner();
        }
        ui.label(
            egui::RichText::new(&state.query.status)
                .color(theme.text_muted)
                .size(12.0),
        );

        ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
            if state.is_connected() {
                let label = if state.browse_all_active() {
                    "Reload databases"
                } else {
                    "Reload schemas"
                };
                if ui
                    .add(
                        egui::Button::new(
                            egui::RichText::new(label)
                                .color(theme.text_muted)
                                .size(12.0),
                        )
                        .fill(theme.surface)
                        .rounding(4.0),
                    )
                    .clicked()
                {
                    state.start_post_connect_load();
                }
            }
        });
    });
}
