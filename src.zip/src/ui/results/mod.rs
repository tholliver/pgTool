pub mod load_more;
pub mod search_bar;
pub mod table;

use crate::app::state::AppState;
use crate::ui::theme::Theme;

pub fn show_panel(ui: &mut egui::Ui, state: &mut AppState, theme: &Theme) {
    if let Some(result) = &state.query.result {
        let cols = result.columns.clone();
        let filter = state.query.filter_text.clone();

        // filter rows client-side
        let filtered_rows: Vec<_> = result
            .rows
            .iter()
            .filter(|row| {
                if filter.is_empty() {
                    return true;
                }
                let f = filter.to_lowercase();
                row.iter().any(|cell| cell.to_lowercase().contains(&f))
            })
            .collect();

        // search bar
        search_bar::show(ui, &mut state.query.filter_text, theme);

        // results table
        table::show(ui, &cols, &filtered_rows, theme);

        // load more
        load_more::show(ui, state, theme);
    } else {
        ui.vertical_centered(|ui| {
            ui.add_space(30.0);
            ui.label(
                egui::RichText::new("No results \u{2014} select a table and run query")
                    .color(theme.text_muted),
            );
        });
    }
}
