use crate::app::state::AppState;
use crate::ui::theme::Theme;

pub fn show(ui: &mut egui::Ui, state: &mut AppState, theme: &Theme) {
    ui.separator();
    ui.horizontal(|ui| {
        let can_load = !state.is_loading() && state.query.result.is_some();
        let btn = ui.add_enabled(
            can_load,
            egui::Button::new(
                egui::RichText::new(format!("Load {} more ↓", state.query.page_size))
                    .color(theme.text)
                    .size(12.0),
            )
            .fill(theme.surface)
            .rounding(4.0),
        );
        if btn.clicked() {
            state.load_more();
        }

        // Quick limit buttons
        ui.separator();
        for limit in &["50", "100", "1000"] {
            if ui
                .add(
                    egui::Button::new(
                        egui::RichText::new(*limit)
                            .color(theme.text_muted)
                            .monospace()
                            .size(11.0),
                    )
                    .fill(theme.surface)
                    .rounding(4.0),
                )
                .clicked()
            {
                state.query.limit_value = limit.to_string();
                state.update_sql();
                state.run_query();
            }
        }
    });
}
